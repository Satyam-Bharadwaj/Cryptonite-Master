import cryptonite.*;
public class clientCryptonite
{
	public static void main(String[] args)
	{
		cryptonite.project p = new cryptonite.project();
	}
}

